package com.company.EJERCICIOS_7_8_9.ejercicios_sesion_7;

import java.util.ArrayList;

public class recorrerString {

    public static void main(String[] args) {

        String[] arrayList = new String[]{"Brais","Sara","Hugo","Anna"};

        for (int i = 0; i < arrayList.length; i++) {
            System.out.println("contiene el valor: " + arrayList[i] );
        }

    }
}
